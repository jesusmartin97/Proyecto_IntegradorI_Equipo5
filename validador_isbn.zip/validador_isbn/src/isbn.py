
from typing import Optional

def normalize_isbn(s: Optional[str]) -> str:
    if s is None:
        return ""
    s = s.replace("-", "").replace(" ", "").upper()
    if s == "":
        return ""
    if s.endswith("X"):
        body = s[:-1]
        if body == "":
            return ""
        if not body.isdigit():
            return ""
        return s
    else:
        if not s.isdigit():
            return ""
        return s

def is_valid_isbn10(s: Optional[str]) -> bool:
    norm = normalize_isbn(s)
    if len(norm) != 10:
        return False
    total = 0
    for i, ch in enumerate(norm):
        weight = 10 - i
        if ch == "X":
            if i != 9:
                return False
            value = 10
        else:
            if not ch.isdigit():
                return False
            value = ord(ch) - ord("0")
        total += weight * value
    return total % 11 == 0

def is_valid_isbn13(s: Optional[str]) -> bool:
    norm = normalize_isbn(s)
    if len(norm) != 13:
        return False
    if not norm.isdigit():
        return False
    total = 0
    for i, ch in enumerate(norm):
        value = ord(ch) - ord("0")
        weight = 1 if (i % 2 == 0) else 3
        total += weight * value
    return total % 10 == 0

def detect_isbn(s: Optional[str]) -> str:
    norm = normalize_isbn(s)
    if len(norm) == 10 and is_valid_isbn10(norm):
        return "ISBN-10"
    if len(norm) == 13 and is_valid_isbn13(norm):
        return "ISBN-13"
    return "INVALID"

