import pytest
from src import isbn

VALID_ISBN10 = [
    "0-306-40615-2",
    "0471958697",
    "0306406152"
]
VALID_ISBN10_WITH_X = [
    "0-8044-2957-X",
    "080442957X"
]
INVALID_ISBN10 = [
    "",
    "123456789",
    "12345678901",
    "ABCDEFGHIJ",
    "0123456789X",
    "0-306-40615-3"
]

@pytest.mark.parametrize("s", VALID_ISBN10)
def test_valid_isbn10_digits(s):
    assert isbn.is_valid_isbn10(s) is True

@pytest.mark.parametrize("s", VALID_ISBN10_WITH_X)
def test_valid_isbn10_with_X(s):
    assert isbn.is_valid_isbn10(s) is True

@pytest.mark.parametrize("s", INVALID_ISBN10)
def test_invalid_isbn10(s):
    assert isbn.is_valid_isbn10(s) is False

def test_isbn10_X_not_in_middle():
    assert isbn.is_valid_isbn10("0X0442957X") is False

