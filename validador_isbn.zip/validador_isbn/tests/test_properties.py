import random
from src import isbn

random.seed(42)

def test_normalize_idempotent():
    samples = [
        " 978-0-306-40615-7 ",
        "0-8044-2957-X",
        " 0471958697 ",
        None,
        ""
    ]
    for s in samples:
        first = isbn.normalize_isbn(s)
        second = isbn.normalize_isbn(first)
        assert first == second

def test_normalization_stability_equivalent_formats():
    examples = [
        ("978-0-306-40615-7", "9780306406157"),
        ("0-306-40615-2", "0306406152"),
        ("0 8044 2957 X", "080442957X"),
    ]
    for a, b in examples:
        assert isbn.normalize_isbn(a) == isbn.normalize_isbn(b)
        assert isbn.detect_isbn(a) == isbn.detect_isbn(b)

def test_small_random_mutations_do_not_collide():
    base = "0306406152"
    for i in range(5):
        idx = random.randrange(0, len(base))
        mutated = list(base)
        mutated[idx] = str((int(mutated[idx]) + 1) % 10)
        mutated = "".join(mutated)
        assert isbn.is_valid_isbn10(mutated) is False or isbn.detect_isbn(mutated) != "ISBN-10"

