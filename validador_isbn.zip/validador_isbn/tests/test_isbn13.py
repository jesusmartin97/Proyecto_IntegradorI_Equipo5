import pytest
from src import isbn

VALID_ISBN13 = [
    "9780306406157",
    "978-3-16-148410-0",
    "9780306406157"
]
INVALID_ISBN13 = [
    "",
    "978030640615",
    "97803064061570",
    "978030640615X",
    "9780306406158"
]

@pytest.mark.parametrize("s", VALID_ISBN13)
def test_valid_isbn13(s):
    assert isbn.is_valid_isbn13(s) is True

@pytest.mark.parametrize("s", INVALID_ISBN13)
def test_invalid_isbn13(s):
    assert isbn.is_valid_isbn13(s) is False

